﻿DELETE FROM "Orderrule";
DELETE FROM "Item";
DELETE FROM "Category";
DELETE FROM "Supplier";
DELETE FROM "Order";
DELETE FROM "Customer";
