﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopManagementSystem
{
    partial class Orderrule
    {
        // Used for CreateForm adding orderrules to an order
        // Not used in the dbase design
        public decimal Amount { get; set; }
    }
}
